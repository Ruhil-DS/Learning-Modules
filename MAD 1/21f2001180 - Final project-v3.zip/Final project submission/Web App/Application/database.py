from flask_sqlalchemy import SQLAlchemy

# Creating a database variable to communicate with the database file! Using SQLAlchemy ORM for it
db = SQLAlchemy()
